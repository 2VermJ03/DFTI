/*
	Jay Verma
	Q12027103
	
	Javascript for date to be placed in the footer section

*/

var d = new Date();
document.getElementById("footerDate").innerHTML = d.toDateString();