<?php

/*	
	Jay Verma
	Q12027103
	
	PHP signup script
	
*/

$f_name = $_GET["f_name"];
$l_name = $_GET["l_name"];
$email = $_GET["email"];
$u_name = $_GET["u_name"];
$p_word = $_GET["p_word"];








?>