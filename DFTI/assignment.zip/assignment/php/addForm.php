<?php

/*	
	Jay Verma
	Q12027103
	
	PHP addForm script
	
*/

$addFormName = $_POST["addFormName"];
$addFormType = $_POST["addFormType"];
$addFormDesc = $_POST["addFormDesc"];









?>